<?php

if (!defined('WP_CLI') || !WP_CLI) {
    return;
}

/**
 * WP-CLI commands for MSH Image Optimizer.
 */
class MSH_CLI {
    /**
     * Manage seasonal caching.
     *
     * ## OPTIONS
     *
     * <subcommand>
     * : The operation to perform. Accepts `get`, `set`, or `clear`.
     *
     * [<season>]
     * : Season identifier when using the `set` command. Valid values: winter, spring, summer, fall.
     *
     * [--ttl=<seconds>]
     * : Optional cache lifetime when setting a season (defaults to 24 hours).
     *
     * ## EXAMPLES
     *
     *     wp msh season get
     *     wp msh season set winter --ttl=3600
     *     wp msh season clear
     *
     * @param array $args Positional arguments.
     * @param array $assoc_args Associative arguments.
     */
    public function season($args, $assoc_args) {
        $command = $args[0] ?? 'get';

        $optimizer = new MSH_Contextual_Meta_Generator();

        switch ($command) {
            case 'get':
                $season = $optimizer->get_current_season();
                WP_CLI::success("Current detected season: {$season}");
                break;

            case 'set':
                $season = $args[1] ?? '';
                if ($season === '') {
                    WP_CLI::error('Please specify a season: winter, spring, summer, fall');
                }
                $ttl = isset($assoc_args['ttl']) ? (int) $assoc_args['ttl'] : DAY_IN_SECONDS;
                if ($optimizer->set_season($season, $ttl)) {
                    WP_CLI::success("Season override set to: {$season} (TTL: {$ttl}s)");
                } else {
                    WP_CLI::error('Invalid season. Use: winter, spring, summer, fall');
                }
                break;

            case 'clear':
                $optimizer->clear_season_cache();
                WP_CLI::success('Season cache cleared.');
                break;

            default:
                WP_CLI::error('Unknown command. Use: get, set, or clear');
        }
    }
}

WP_CLI::add_command('msh', 'MSH_CLI');
